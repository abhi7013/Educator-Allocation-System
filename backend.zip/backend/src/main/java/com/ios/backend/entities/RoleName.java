package com.ios.backend.entities;

public enum  RoleName {
    ROLE_USER,
    ROLE_PUBLIC,
    ROLE_ADMIN
}