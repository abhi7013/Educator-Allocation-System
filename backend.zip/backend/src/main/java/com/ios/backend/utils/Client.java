package com.ios.backend.utils;

public class Client {
  public final static String clientUrl = "http://localhost:8000";
}
