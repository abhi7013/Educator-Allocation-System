export class CodeDTO {
  code: string;
  uid: number;
  constructor() {
  }
}
