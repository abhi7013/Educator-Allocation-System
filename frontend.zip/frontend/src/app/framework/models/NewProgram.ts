export class NewProgram {
  public id: number;
  public name: string;
  public description: string;
  public admin: number;
  public users: number[] = [];
  constructor() {
  }
}
