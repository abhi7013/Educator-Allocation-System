export class Task {
  public id: number;
  public program: number;
  public name: string;
  public createdBy: number;
  public startTime: string;
  public createdTime: string;
  public deadline: string;
  public modifiedBy: number;
  public modifiedTime: string;
  public status: string;
  public description: string;
  constructor() {
  }
}
