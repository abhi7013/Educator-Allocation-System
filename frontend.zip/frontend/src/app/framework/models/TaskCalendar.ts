export class TaskCalendar {
  title: string;
  start: string;
  end: string;
  constructor() {}
}
