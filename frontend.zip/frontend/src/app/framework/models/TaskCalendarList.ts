import { TaskCalendar } from './TaskCalendar';

export class TaskCalendarList {
  events: TaskCalendar[];
  constructor() {}
}
