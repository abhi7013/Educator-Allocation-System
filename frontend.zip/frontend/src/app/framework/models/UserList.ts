import { User } from './User';

export class UserList {
  userList: User[];
  constructor() {}
}
