export class  Work {
  public work: string;
  constructor() {
  }
}
